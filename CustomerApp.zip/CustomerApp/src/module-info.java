/**
 * 
 */
/**
 * 
 */
module CustomerApp {
	requires java.desktop;
}
package Interface;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Login {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Login window = new Login();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Cake Shop Login");
		frame.setBounds(100, 100, 800, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 253, 208)); // Cream background
		contentPane.setLayout(null);
		frame.setContentPane(contentPane);

		JLabel lblTitle = new JLabel("Oriental Coffee");
		lblTitle.setForeground(new Color(128, 0, 0));
		lblTitle.setFont(new Font("Showcard Gothic", Font.BOLD, 60));
		lblTitle.setBounds(143, 68, 543, 105);
		contentPane.add(lblTitle);

		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Cambria Math", Font.PLAIN, 24));
		lblUsername.setBounds(206, 210, 177, 55);
		contentPane.add(lblUsername);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Cambria Math", Font.PLAIN, 24));
		lblPassword.setBounds(206, 275, 177, 55);
		contentPane.add(lblPassword);

		textField = new JTextField();
		textField.setBounds(332, 222, 211, 33);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(332, 281, 211, 33);
		contentPane.add(textField_1);

		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setFont(new Font("Rockwell", Font.PLAIN, 20));
		btnLogin.setBounds(359, 350, 159, 39);
		contentPane.add(btnLogin);

		btnLogin.addActionListener(e -> {
			String username = textField.getText();
			String password = textField_1.getText();

			Login_Controller loginController = new Login_Controller();
			Integer customerId = loginController.handleLogin(username, password); // Get customerId

			if (customerId != null) {
				frame.setVisible(false); // Hide login window
				Cake_GUI cakeGUI = new Cake_GUI(customerId); // Show Cake_GUI with customerId
				cakeGUI.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(frame, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
			}
		});

		JButton btnSignUp = new JButton("SIGN UP");
		btnSignUp.setFont(new Font("Rockwell", Font.PLAIN, 20));
		btnSignUp.setBounds(498, 429, 159, 45);
		contentPane.add(btnSignUp);


		JButton btnExit = new JButton("EXIT");
		btnExit.setFont(new Font("Rockwell", Font.PLAIN, 20));
		btnExit.setBounds(259, 429, 159, 45);
		contentPane.add(btnExit);

		btnExit.addActionListener(e -> System.exit(0));
	}
}
